# Dhiraj Kumar Yadav — Premium Portfolio

A responsive personal portfolio website built with plain HTML, CSS, and JavaScript.

## Preview locally
1. Extract `dhiraj_premium_portfolio.zip`.
2. Open the folder.
3. Double-click `index.html` to open it in your browser.

For a local development server, open a terminal in this folder and run:
- Python: `python -m http.server 8000`
- Then visit `http://localhost:8000`

## Publish for free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository (for example, `dhiraj-portfolio`).
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for the deployment to finish. GitHub will show your public website URL in the Pages section.

Alternative: Netlify Drop can publish a static site by uploading the extracted site folder, depending on its current interface and account requirements.

## Personalize before publishing
Search `index.html` for the following placeholders and replace them:
- `[Your city, Nepal]`
- `[Your school / college]`
- `your.email@example.com`
- `Add your profile link`
- `[Add ...]` skill and hobby descriptions
- `EST. 2008? (EDIT ME)` — remove or replace this line with your preferred label; the year is only a placeholder.

Also update the page title and description if you want. The site uses Google Fonts when online, with fallback fonts if they cannot load.

## Privacy
The profile photo is included in the `assets` folder and will be publicly viewable once the site is published. Only add contact details you are comfortable sharing publicly.
